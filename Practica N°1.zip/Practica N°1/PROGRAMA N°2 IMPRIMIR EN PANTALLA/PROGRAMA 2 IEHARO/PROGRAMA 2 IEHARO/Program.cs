﻿//ISAAC HARO
//Sacar el cuadrado y el cubo de un número x.
//El programa atrapa un número del usuario el mismo que mostrara su potencia al cuadrado o al cubo.
//Version 1.0
//Fecha de creación: 26/02/2020
//Ultima fecha de actualización: 26/02/2020

//Nos ayuda a tener datos para soluciones Matemáticas
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROGRAMA_2_IEHARO
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ingreso de la variables NOMBRE, APELLIDO, EDAD, Y CARRERA.
            string nomb, apell, edad, carrer;
            //Ingresa el nombre y se guarda en una variable.
            Console.WriteLine("Ingrese su nombre:");
            nomb = Console.ReadLine();
            //Ingresa el apellido y se guarda en una variable.
            Console.WriteLine("Ingrese su apellido:");
            apell = Console.ReadLine();
            //Ingresa la edad y se guarda en una variable.
            Console.WriteLine("Ingrese su edad:");
            edad = Console.ReadLine();
            //Ingresa su carrera
            Console.WriteLine("Ingrese su carrera:");
            carrer = Console.ReadLine();
            Console.Clear();
            //El programa se ejcutara e imprimira en pantalla lo siguiente.
            Console.Write("Su nombre es: " + nomb); Console.Write(" " + apell); Console.Write("  tiene " + edad); Console.Write("  y estudia " + carrer);
            Console.ReadKey();

        }
    }
}
