﻿//ISAAC HARO
//Sacar el cuadrado y el cubo de un número x.
//El programa atrapa un número del usuario el mismo que mostrara su potencia al cuadrado o al cubo.
//Version 1.0
//Fecha de creación: 26/02/2020
//Ultima fecha de actualización: 26/02/2020

//Nos ayuda a tener datos para soluciones Matemáticas
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Nombre del Programa
namespace Cuadrado_y_Cubo
{
    //Clase del Programa
    class Program
    {
        //Estatico, no retorna y usa string argumentos.
        static void Main(string[] args)
        {
            //Algoritmo del cuadrado o cubo de un numero.

            double num, pot, resultado;
            Console.WriteLine("Digite el número que desea elevar:");
            //Trata el numero que digite como un double.
            num = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Digite a la potencia cuadrada o cubica:");
            //Trata el numero que digite como un double.
            pot = Convert.ToDouble(Console.ReadLine());
            //Sirve dos parametros de tipo double para la potencia.
            resultado = Math.Pow(num, pot);
            //Imprime el resultado en pantalla.
            Console.WriteLine("El resultado es:"+ resultado);
            Console.ReadKey();
        }

    }
}
